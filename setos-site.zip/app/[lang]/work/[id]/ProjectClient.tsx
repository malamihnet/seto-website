"use client"

import { useEffect, useState } from "react"
import Link from "next/link"

type VimeoVideo = {
id:number
title:string
description:string
thumbnail_large:string
}

export default function ProjectClient({
id,
lang
}:{
id:string
lang:string
}){

const isArabic = lang === "ar"

const [video,setVideo] = useState<VimeoVideo | null>(null)

useEffect(()=>{

if(!id) return

fetch(`https://vimeo.com/api/v2/video/${id}.json`)
.then(res=>{
if(!res.ok) throw new Error("Fetch failed")
return res.json()
})
.then(data=>{
if(data && data[0]) setVideo(data[0])
})
.catch(()=>{})

},[id])

if(!video){
return(
<div className="min-h-screen bg-black text-white flex items-center justify-center">
{isArabic ? "جاري التحميل..." : "Loading..."}
</div>
)
}

const cleanDescription = video.description
?.replace(/<br\s*\/?>/gi," ")
?.replace("Post-Production:","POST PRODUCTION BY ")
?.trim()

return(

<div className={`min-h-screen bg-black text-white pt-5 pb-32 px-6 md:px-16 ${isArabic ? "text-right" : ""}`}>

{/* VIDEO */}

<div className="max-w-[1400px] mx-auto aspect-video mb-16 rounded-xl overflow-hidden">

<iframe
src={`https://player.vimeo.com/video/${video.id}?autoplay=1`}
className="w-full h-full"
allow="autoplay; fullscreen"
/>

</div>


{/* TITLE */}

<div className="max-w-[900px] mx-auto text-center">

<h1 className="text-4xl md:text-6xl uppercase mb-8">
{video.title}
</h1>


{/* DESCRIPTION */}

<p className="text-neutral-400 text-lg mb-14 tracking-wide">
{cleanDescription}
</p>


{/* BUTTONS */}

<div className="flex flex-col md:flex-row gap-6 justify-center">

<Link
href={`/${lang}/work`}
className="border border-white px-8 py-3 uppercase text-sm tracking-widest hover:bg-white hover:text-black transition"
>
{isArabic ? "العودة للأعمال" : "Back To Work"}
</Link>

<Link
href={`/${lang}/contact`}
className="bg-[#e4da20] text-black px-8 py-3 uppercase text-sm tracking-widest hover:opacity-90 transition"
>
{isArabic ? "لنبدأ مشروعك" : "Let's Work Together"}
</Link>

</div>

</div>

</div>

)

}