"use client"

import { useEffect, useState, useRef } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { FaPlay } from "react-icons/fa"
import { motion } from "framer-motion"

type VimeoVideo = {
  id:number
  thumbnail_large:string
  title:string
}

export default function Work(){

const { lang } = useParams<{ lang:string }>()
const isArabic = lang === "ar"

const title = isArabic
? "سيتو بوست برودكشن"
: "SETO'S POST-PRODUCTION"

const latestWork = isArabic
? "أحدث الأعمال"
: "LATEST WORK"

const loadingText = isArabic
? "جاري التحميل..."
: "LOADING..."

const [videos,setVideos] = useState<VimeoVideo[]>([])
const [modalVideo,setModalVideo] = useState<number | null>(null)
const [visible,setVisible] = useState(6)
const [loading,setLoading] = useState(false)

const loadRef = useRef<HTMLDivElement | null>(null)

useEffect(()=>{

fetch("https://vimeo.com/api/v2/setoiq/videos.json")
.then(res=>res.json())
.then(data=>{

setVideos(data.reverse())

})

},[])



/* INFINITE SCROLL */

useEffect(()=>{

const observer = new IntersectionObserver(

(entries)=>{

const entry = entries[0]

if(entry.isIntersecting && !loading && visible < videos.length){

setLoading(true)

setTimeout(()=>{

setVisible(v => v + 6)

setLoading(false)

},1200)

}

},

{threshold:1}

)

if(loadRef.current) observer.observe(loadRef.current)

return ()=>observer.disconnect()

},[loading,visible,videos.length])



const heroVideo = videos[0]

return(

<div className="pt-6 pb-32 overflow-x-hidden bg-black">
  
{/* SEO H1 */}

<h1 className="sr-only">
Seto's Post Production Iraq | #1 Post Production Studio in Iraq
</h1>



{/* HERO */}

{heroVideo && (

<motion.div
initial={{opacity:0}}
animate={{opacity:1}}
transition={{duration:1.2}}
className="relative mb-24 w-full"
>

<div className="aspect-[16/9] md:aspect-[24/8] rounded-3xl overflow-hidden mx-3 md:mx-10 relative">

<iframe
src={`https://player.vimeo.com/video/${heroVideo.id}?background=1&autoplay=1&muted=1&loop=1&autopause=0`}
className="absolute top-1/2 left-1/2 w-[200%] h-[200%] md:w-[150%] md:h-[180%] -translate-x-1/2 -translate-y-1/2 grayscale brightness-[0.65] pointer-events-none"
allow="autoplay; fullscreen; picture-in-picture"
/>

<div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"/>

</div>

<div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-4">

<motion.h2
initial={{opacity:0,y:80,scale:0.95,filter:"blur(14px)"}}
animate={{opacity:1,y:0,scale:1,filter:"blur(0px)"}}
transition={{duration:1.8,ease:"easeOut"}}
className="uppercase text-3xl sm:text-4xl md:text-7xl font-semibold text-[#e4da20]"
>
{title}
</motion.h2>

<motion.p
initial={{opacity:0,y:60,scale:0.95,filter:"blur(12px)"}}
animate={{opacity:1,y:0,scale:1,filter:"blur(0px)"}}
transition={{duration:1.8,delay:0.4,ease:"easeOut"}}
className="uppercase text-sm md:text-xl text-white tracking-widest mt-4"
>
{latestWork}
</motion.p>

</div>

</motion.div>

)}



{/* GRID */}

<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 px-4 md:px-10">

{videos.slice(1,visible+1).map(video=>(

<Link key={video.id} href={`/${lang}/work/${video.id}`}>

<motion.div
initial={{opacity:0,y:40}}
whileInView={{opacity:1,y:0}}
viewport={{once:true}}
transition={{duration:0.5}}
whileHover={{y:-6}}
className="cursor-pointer group"
>

<div className="aspect-video relative overflow-hidden bg-black">

<img
src={video.thumbnail_large}
className="w-full h-full object-cover transition duration-700 group-hover:scale-105"
alt={`${isArabic ? "سيتو بوست برودكشن" : "Seto Post Production"} - ${video.title}`}
/>

<div className="absolute inset-0 flex items-center justify-center">
<FaPlay className="text-white text-2xl opacity-90 group-hover:scale-110 transition"/>
</div>

</div>

<p className="uppercase text-white text-sm mt-3 font-medium">
{video.title}
</p>

</motion.div>

</Link>

))}

</div>



{/* LOADING */}

{visible < videos.length && (

<div ref={loadRef} className="flex justify-center mt-20 h-20">

{loading && (
<div className="text-white text-sm tracking-widest animate-pulse">
{loadingText}
</div>
)}

</div>

)}

</div>

)

}